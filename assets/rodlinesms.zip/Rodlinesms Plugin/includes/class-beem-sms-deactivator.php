<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://beem.africa/
 * @since      2.0.0
 *
 * @package    Beem_Sms
 * @subpackage Beem_Sms/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      2.0.0
 * @package    Beem_Sms
 * @subpackage Beem_Sms/includes
 * @author     Beem Africa <contact@beem.africa>
 */
class Beem_Sms_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    2.0.0
	 */
	public static function deactivate() {

	}

}
